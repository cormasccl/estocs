<?php
/**
 * Template for Generating Sidebars for Tablets and Mobile Devices
 */
?>

<div class="flexi-sidebar sidebar left-sidebar">
	<a href="" id="res-sidebar-trigger" class="icon icon-plus res-sidebar-trigger"></a>
	<div class="inner-flexi-sidebar">
		
	</div>
</div>